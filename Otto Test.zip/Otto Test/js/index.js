window.addEventListener("DOMContentLoaded", (event) => {
  const sidebarToggle = document.body.querySelector("#sidebarToggle");
  if (sidebarToggle) {
    sidebarToggle.addEventListener("click", (event) => {
      event.preventDefault();
      document.body.classList.toggle("sb-sidenav-toggled");
      localStorage.setItem("sb|sidebar-toggle", document.body.classList.contains("sb-sidenav-toggled"));
    });
  }
});

$(document).ready(function () {
  // Prepare the preview for profile picture
  $("#wizard-picture").change(function () {
    readURL(this);
  });
});
function readURL(input) {
  if (input.files && input.files[0]) {
    var reader = new FileReader();

    reader.onload = function (e) {
      $("#wizardPicturePreview").attr("src", e.target.result).fadeIn("slow");
    };
    reader.readAsDataURL(input.files[0]);
  }
}

$(document).ready(function () {
  var date_input = $('input[name="date"]');
  var container = $(".bootstrap-iso form").length > 0 ? $(".bootstrap-iso form").parent() : "body";
  date_input.datepicker({
    format: "mm/dd/yyyy",
    container: container,
    todayHighlight: true,
    autoclose: true,
  });
});

$(document).ready(function () {
  $("button").click(function () {
    $("#wizardPicturePreview").remove();
  });
});
